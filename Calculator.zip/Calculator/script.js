let display = document.getElementById("display");


function append(value){

display.value += value;

}



function clearDisplay(){

display.value="";

}



function deleteChar(){

display.value =
display.value.slice(0,-1);

}



function calculate(){

let expression = display.value;


try{


let result = eval(expression);


display.value=result;


//send data to database

fetch("http://localhost:5000/save",{

method:"POST",

headers:{
"Content-Type":"application/json"
},

body:JSON.stringify({

expression:expression,
result:result

})

});


}

catch{

display.value="Error";

}

}